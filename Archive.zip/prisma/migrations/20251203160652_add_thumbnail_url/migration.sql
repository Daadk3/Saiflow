-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "thumbnailUrl" TEXT;
