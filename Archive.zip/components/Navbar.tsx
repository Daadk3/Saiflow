"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";

export default function Navbar() {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Don't show navbar on dashboard pages (they have their own navigation)
  if (pathname?.startsWith("/dashboard")) {
    return null;
  }

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [pathname]);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isMobileMenuOpen]);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#0A0A0A]/80 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3" onClick={closeMobileMenu}>
              <Image
                src="/mascot.png"
                alt="Saiflow"
                width={48}
                height={48}
                className="h-12 w-auto object-contain"
                priority
              />
              <span className="text-2xl font-bold text-white">Saiflow</span>
            </Link>

            {/* Desktop Nav Links */}
            <div className="hidden md:flex items-center gap-8">
              <Link 
                href="/browse" 
                className={`text-sm font-medium transition-colors ${
                  pathname === "/browse" ? "text-teal-400" : "text-gray-400 hover:text-white"
                }`}
              >
                Products
              </Link>
              <Link 
                href="/features" 
                className={`text-sm font-medium transition-colors ${
                  pathname === "/features" ? "text-teal-400" : "text-gray-400 hover:text-white"
                }`}
              >
                Features
              </Link>
              <Link 
                href="/pricing" 
                className={`text-sm font-medium transition-colors ${
                  pathname === "/pricing" ? "text-teal-400" : "text-gray-400 hover:text-white"
                }`}
              >
                Pricing
              </Link>
            </div>

            {/* Desktop Right Side Links */}
            <div className="hidden md:flex items-center gap-6">
              <Link
                href="/support"
                className={`text-sm font-medium transition-colors ${
                  pathname === "/support" ? "text-teal-400" : "text-gray-400 hover:text-white"
                }`}
              >
                Support
              </Link>
              <Link
                href="/login"
                className="text-gray-400 hover:text-white transition-colors text-sm font-medium"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="border border-teal-500 text-teal-400 hover:bg-teal-500 hover:text-black text-sm font-semibold px-5 py-2 rounded-full transition-all duration-200"
              >
                Get Started
              </Link>
            </div>

            {/* Mobile Hamburger Button */}
            <button
              onClick={toggleMobileMenu}
              className="md:hidden p-2 text-gray-400 hover:text-white transition-colors"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? (
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <>
        {/* Backdrop */}
        <div
          className={`fixed inset-0 bg-black/50 z-40 md:hidden transition-opacity duration-300 ${
            isMobileMenuOpen ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
          onClick={closeMobileMenu}
        />

        {/* Mobile Menu Panel */}
        <div
          className={`fixed top-0 right-0 h-full w-80 max-w-[85vw] bg-[#0A0A0A] border-l border-white/10 z-50 md:hidden transform transition-transform duration-300 ease-in-out ${
            isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
          }`}
        >
          <div className="flex flex-col h-full">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <span className="text-xl font-bold text-white">Menu</span>
              <button
                onClick={closeMobileMenu}
                className="p-2 text-gray-400 hover:text-white transition-colors"
                aria-label="Close menu"
              >
                <svg
                  className="w-6 h-6"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>

            {/* Menu Items */}
            <div className="flex-1 overflow-y-auto py-6">
              <nav className="space-y-2 px-4">
                <Link
                  href="/browse"
                  onClick={closeMobileMenu}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                    pathname === "/browse"
                      ? "bg-teal-500/10 text-teal-400 border border-teal-500/20"
                      : "text-gray-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  Products
                </Link>
                <Link
                  href="/features"
                  onClick={closeMobileMenu}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                    pathname === "/features"
                      ? "bg-teal-500/10 text-teal-400 border border-teal-500/20"
                      : "text-gray-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  Features
                </Link>
                <Link
                  href="/pricing"
                  onClick={closeMobileMenu}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                    pathname === "/pricing"
                      ? "bg-teal-500/10 text-teal-400 border border-teal-500/20"
                      : "text-gray-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  Pricing
                </Link>
                <Link
                  href="/support"
                  onClick={closeMobileMenu}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                    pathname === "/support"
                      ? "bg-teal-500/10 text-teal-400 border border-teal-500/20"
                      : "text-gray-300 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  Support
                </Link>
              </nav>

              {/* Divider */}
              <div className="my-6 px-4">
                <div className="border-t border-white/10" />
              </div>

              {/* Auth Links */}
              <div className="space-y-2 px-4">
                <Link
                  href="/login"
                  onClick={closeMobileMenu}
                  className="block px-4 py-3 rounded-xl text-base font-medium text-gray-300 hover:bg-white/5 hover:text-white transition-colors"
                >
                  Login
                </Link>
                <Link
                  href="/signup"
                  onClick={closeMobileMenu}
                  className="block px-4 py-3 rounded-xl text-base font-semibold bg-teal-500 hover:bg-teal-400 text-black text-center transition-colors"
                >
                  Get Started
                </Link>
              </div>
            </div>
          </div>
        </div>
      </>
    </>
  );
}

