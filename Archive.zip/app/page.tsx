import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="pt-16 pb-16 sm:pt-24 sm:pb-24 px-4 relative overflow-hidden">
        {/* Floating decorative mascots */}
        <div className="absolute top-32 right-8 w-20 h-20 opacity-10 animate-float pointer-events-none hidden lg:block">
          <Image
            src="/mascot-camera.png"
            alt=""
            width={80}
            height={80}
            className="w-full h-full object-contain"
          />
        </div>
        <div className="absolute bottom-32 left-8 w-24 h-24 opacity-10 animate-float-delayed pointer-events-none hidden lg:block">
          <Image
            src="/mascot-reading.png"
            alt=""
            width={96}
            height={96}
            className="w-full h-full object-contain"
          />
        </div>
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left - Text Content */}
            <div className="text-center lg:text-left">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-teal-500/10 border border-teal-500/20 mb-6">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-teal-500"></span>
                </span>
                <span className="text-teal-400 text-sm font-medium">Now with instant payouts</span>
              </div>

              {/* Headline */}
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.1]">
                Let your
                <span className="block text-teal-400">creativity flow</span>
              </h1>

              {/* Subheadline */}
              <p className="mt-6 text-xl text-gray-400 max-w-lg mx-auto lg:mx-0 leading-relaxed">
                Sell digital products, courses, and memberships. 
                Start earning in minutes, not months.
              </p>

              {/* CTA Buttons */}
              <div className="mt-10 flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                <Link
                  href="/signup"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-teal-500 hover:bg-teal-400 text-black font-semibold px-8 py-4 rounded-full transition-all duration-200 shadow-lg shadow-teal-500/25 hover:shadow-xl hover:shadow-teal-500/30"
                >
                  Start Selling — It&apos;s Free
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </Link>
                <Link
                  href="/browse"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-white font-semibold px-8 py-4 rounded-full border border-white/10 hover:border-white/20 transition-all duration-200"
                >
                  Browse Products
                </Link>
              </div>

              {/* Social Proof */}
              <div className="mt-10 flex items-center gap-4 justify-center lg:justify-start">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div
                      key={i}
                      className="w-10 h-10 rounded-full bg-gradient-to-br from-gray-700 to-gray-600 border-2 border-[#0A0A0A] flex items-center justify-center"
                    >
                      <span className="text-gray-400 text-xs font-bold">{i}</span>
                    </div>
                  ))}
                </div>
                <p className="text-sm text-gray-500">
                  <span className="font-semibold text-gray-300">1,000+</span> creators already selling
                </p>
              </div>
            </div>

            {/* Right - Mascot */}
            <div className="relative flex items-center justify-center">
              {/* Main Mascot Image */}
              <div className="relative animate-float">
                <Image
                  src="/logo.png"
                  alt="Saiflow mascot - a friendly teal blob character with laptop"
                  width={400}
                  height={400}
                  className="w-64 sm:w-72 lg:w-80 h-auto drop-shadow-2xl"
                  priority
                />
                
                {/* Glow effect behind mascot */}
                <div className="absolute inset-0 -z-10 bg-teal-500/30 blur-[60px] rounded-full scale-90"></div>
              </div>

              {/* Floating cards */}
              <div className="absolute -left-4 sm:left-0 top-1/4 bg-[#1A1A1A] rounded-2xl shadow-2xl p-4 border border-white/10 animate-float-delayed">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                    <svg className="w-5 h-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">New sale!</p>
                    <p className="font-semibold text-white">+$49.00</p>
                  </div>
                </div>
              </div>

              <div className="absolute -right-4 sm:right-0 bottom-1/4 bg-[#1A1A1A] rounded-2xl shadow-2xl p-4 border border-white/10 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center">
                    <svg className="w-5 h-5 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Downloads</p>
                    <p className="font-semibold text-white">2,847</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Video Section - How It Works */}
      <section className="py-20 sm:py-32 px-4 relative overflow-hidden">
        {/* Background glow effect */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-full max-w-4xl h-96 bg-teal-500/10 blur-[120px] rounded-full"></div>
        </div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 className="text-4xl sm:text-5xl font-extrabold text-white mb-4">
              From Creation to Cash
            </h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Watch how easy it is to start selling your digital products
            </p>
          </div>

          {/* Video Player */}
          <div className="max-w-[800px] mx-auto">
            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl shadow-black/50 bg-[#0A0A0A]">
              {/* Glow effect around video */}
              <div className="absolute -inset-1 bg-gradient-to-r from-teal-500/20 to-cyan-500/20 rounded-2xl blur-xl opacity-50"></div>
              
              {/* YouTube Embed */}
              <div className="relative w-full aspect-video">
                <iframe
                  src="https://www.youtube.com/embed/KwRwMTCCT4k"
                  className="absolute top-0 left-0 w-full h-full rounded-2xl"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section - Bento Grid */}
      <section id="features" className="py-20 sm:py-32 px-4 relative overflow-hidden">
        {/* Floating decorative mascots */}
        <div className="absolute top-20 left-4 w-24 h-24 opacity-8 animate-float pointer-events-none hidden lg:block">
          <Image
            src="/mascot-camera.png"
            alt=""
            width={96}
            height={96}
            className="w-full h-full object-contain"
          />
        </div>
        <div className="absolute bottom-20 right-4 w-20 h-20 opacity-8 animate-float-delayed pointer-events-none hidden lg:block">
          <Image
            src="/mascot-reading.png"
            alt=""
            width={80}
            height={80}
            className="w-full h-full object-contain"
          />
        </div>
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-extrabold text-white">
              Everything you need to sell
            </h2>
            <p className="mt-4 text-xl text-gray-400 max-w-2xl mx-auto">
              No complicated setup. No monthly fees. Just you and your creativity.
            </p>
          </div>

          {/* Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Card 1 - Sell Anything (Large) */}
            <div className="md:col-span-2 bg-[#1A1A1A] rounded-3xl p-8 border border-white/10 hover:border-teal-500/50 transition-colors group relative overflow-hidden">
              {/* Floating mascot decoration */}
              <div className="absolute -top-8 -right-8 w-32 h-32 opacity-20 animate-float-delayed pointer-events-none">
                <Image
                  src="/mascot-headphones.png"
                  alt=""
                  width={128}
                  height={128}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-6 relative z-10">
                <div className="flex-1">
                  <div className="w-14 h-14 rounded-2xl bg-teal-500/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <svg className="w-7 h-7 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Sell anything digital</h3>
                  <p className="text-gray-400 leading-relaxed">
                    E-books, courses, templates, music, art, software, memberships — if you can create it, you can sell it.
                  </p>
                  <div className="mt-6 flex flex-wrap gap-2">
                    {["PDFs", "Videos", "Audio", "Templates", "Courses"].map((tag) => (
                      <span key={tag} className="px-3 py-1 bg-white/5 rounded-full text-sm text-gray-300 font-medium border border-white/10">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                {/* Mascot with headphones */}
                <div className="w-full sm:w-48 h-48 bg-gradient-to-br from-teal-900/40 to-cyan-900/20 rounded-2xl flex items-center justify-center border border-teal-500/20 overflow-hidden relative">
                  <Image
                    src="/mascot-headphones.png"
                    alt="Mascot with headphones"
                    width={192}
                    height={192}
                    className="w-full h-full object-contain animate-float"
                  />
                </div>
              </div>
            </div>

            {/* Card 2 - Get Paid */}
            <div className="bg-[#1A1A1A] rounded-3xl p-8 border border-white/10 hover:border-green-500/50 transition-colors group relative overflow-hidden">
              {/* Floating mascot decoration */}
              <div className="absolute -bottom-4 -right-4 w-24 h-24 opacity-15 animate-float pointer-events-none">
                <Image
                  src="/mascot-shopping.png"
                  alt=""
                  width={96}
                  height={96}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-green-500/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <svg className="w-7 h-7 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold text-white mb-3">Get paid instantly</h3>
                <p className="text-gray-400 leading-relaxed mb-6">
                  Accept payments from anywhere. Support for local and international cards. Get your money fast.
                </p>
                {/* Mascot with shopping bag */}
                <div className="w-full h-32 bg-gradient-to-br from-green-900/30 to-emerald-900/20 rounded-2xl flex items-center justify-center border border-green-500/20 overflow-hidden mb-4">
                  <Image
                    src="/mascot-shopping.png"
                    alt="Mascot with shopping bag"
                    width={128}
                    height={128}
                    className="w-24 h-24 object-contain animate-float-delayed"
                  />
                </div>
                <ul className="space-y-2">
                  {["Global payments", "Instant transfers", "Secure checkout"].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-gray-400 text-sm">
                      <svg className="w-4 h-4 text-green-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Card 3 - Simple Pricing */}
            <div className="bg-gradient-to-br from-teal-900 to-teal-800 rounded-3xl p-8 border border-teal-500/30 group text-white">
              <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                </svg>
              </div>
              <h3 className="text-2xl font-bold mb-3">Simple pricing</h3>
              <p className="text-teal-100/70 leading-relaxed mb-6">
                No monthly fees. No setup costs. Just a small percentage when you make a sale.
              </p>
              <div className="flex items-baseline gap-1">
                <span className="text-5xl font-extrabold">9%</span>
                <span className="text-teal-200/60">per sale</span>
              </div>
            </div>

            {/* Card 4 - Track Sales */}
            <div className="md:col-span-2 bg-[#1A1A1A] rounded-3xl p-8 border border-white/10 hover:border-purple-500/50 transition-colors group relative overflow-hidden">
              {/* Floating mascot decoration */}
              <div className="absolute -top-6 -left-6 w-28 h-28 opacity-15 animate-float pointer-events-none">
                <Image
                  src="/mascot-tablet.png"
                  alt=""
                  width={112}
                  height={112}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col sm:flex-row gap-6 relative z-10">
                <div className="flex-1">
                  <div className="w-14 h-14 rounded-2xl bg-purple-500/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <svg className="w-7 h-7 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3">Track your sales</h3>
                  <p className="text-gray-400 leading-relaxed">
                    Beautiful dashboard to see your revenue, customers, and product performance. Know what&apos;s working.
                  </p>
                </div>
                {/* Mascot with tablet */}
                <div className="w-full sm:w-48 h-48 bg-gradient-to-br from-purple-900/30 to-pink-900/20 rounded-2xl flex items-center justify-center border border-purple-500/20 overflow-hidden relative">
                  <Image
                    src="/mascot-tablet.png"
                    alt="Mascot with tablet"
                    width={192}
                    height={192}
                    className="w-full h-full object-contain animate-float-delayed"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 sm:py-32 px-4 relative overflow-hidden">
        {/* Floating decorative mascots */}
        <div className="absolute top-10 left-10 w-20 h-20 opacity-10 animate-float pointer-events-none hidden lg:block">
          <Image
            src="/mascot-camera.png"
            alt=""
            width={80}
            height={80}
            className="w-full h-full object-contain"
          />
        </div>
        <div className="absolute bottom-10 right-10 w-24 h-24 opacity-10 animate-float-delayed pointer-events-none hidden lg:block">
          <Image
            src="/mascot-reading.png"
            alt=""
            width={96}
            height={96}
            className="w-full h-full object-contain"
          />
        </div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10">
          {/* Mascot near CTA */}
          <div className="flex justify-center mb-8">
            <div className="w-32 h-32 sm:w-40 sm:h-40 animate-float">
              <Image
                src="/mascot-reading.png"
                alt="Mascot reading"
                width={160}
                height={160}
                className="w-full h-full object-contain"
              />
            </div>
          </div>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-white mb-6">
            Ready to start earning?
          </h2>
          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
            Join thousands of creators who are already selling their digital products with Saiflow.
          </p>
          <Link
            href="/signup"
            className="inline-flex items-center gap-2 bg-teal-500 hover:bg-teal-400 text-black font-semibold px-10 py-5 rounded-full text-lg transition-all duration-200 shadow-lg shadow-teal-500/25 hover:shadow-xl hover:shadow-teal-500/30"
          >
            Create Your Free Store
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </Link>
          <p className="mt-4 text-sm text-gray-500">
            Free to start • No credit card required
          </p>
        </div>
      </section>
    </div>
  );
}
