import NextAuth, { NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import type { Adapter, AdapterUser } from "next-auth/adapters";
import { prisma } from "@/lib/prisma";
import bcrypt from "bcrypt";

// Prisma adapter with a safe createUser that always sets a password for OAuth
const baseAdapter = PrismaAdapter(prisma);

const adapter: Adapter = {
  ...baseAdapter,
  async createUser(user: Omit<AdapterUser, "id">) {
    // Case-insensitive lookup to avoid duplicates
    const existingUser = await prisma.user.findFirst({
      where: { email: { equals: user.email!, mode: "insensitive" } },
    });
    if (existingUser) {
      return existingUser;
    }

    // Ensure we satisfy the required password field with a generated hash
    const dummyPassword = await bcrypt.hash(
      `oauth-${user.email}-${Date.now()}`,
      10
    );

    const created = await prisma.user.create({
      data: {
        email: user.email!,
        name: user.name,
        image: user.image,
        emailVerified: user.emailVerified,
        password: dummyPassword,
      },
    });

    return {
      id: created.id,
      email: created.email,
      name: created.name,
      image: created.image,
      emailVerified: created.emailVerified,
    };
  },
};

export const authOptions: NextAuthOptions = {
  adapter,
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      // Explicit profile mapping to ensure id/email/name/image are present
      profile(profile) {
        return {
          id: profile.sub,
          name: profile.name,
          email: profile.email,
          image: profile.picture,
        };
      },
    }),
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error("Missing email or password");
        }

        // Case-insensitive email lookup for credentials
        const user = await prisma.user.findFirst({
          where: {
            email: { equals: credentials.email, mode: "insensitive" },
          },
        });

        if (!user || !user.password) {
          throw new Error("User not found");
        }

        const valid = await bcrypt.compare(credentials.password, user.password);
        if (!valid) {
          throw new Error("Incorrect password");
        }

        return { id: user.id, email: user.email, name: user.name };
      },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = (user as any).id;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user && token.id) {
        (session.user as any).id = token.id as string;
      }
      return session;
    },
  },
};

// NextAuth API route handler
const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
