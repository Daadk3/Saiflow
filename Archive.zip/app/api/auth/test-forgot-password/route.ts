import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { Resend } from "resend";
import crypto from "crypto";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const email = searchParams.get("email");

  if (!email) {
    return NextResponse.json({ error: "Please provide ?email=your@email.com" }, { status: 400 });
  }

  // Check environment
  const checks = {
    hasResendKey: !!process.env.RESEND_API_KEY,
    resendKeyPrefix: process.env.RESEND_API_KEY?.substring(0, 10) + "...",
    nextAuthUrl: process.env.NEXTAUTH_URL,
  };

  // Check if user exists (case-insensitive)
  let userExists = false;
  try {
    const user = await prisma.user.findFirst({
      where: {
        email: {
          equals: email,
          mode: "insensitive",
        },
      },
      select: { id: true, email: true },
    });
    userExists = !!user;
  } catch (dbError) {
    return NextResponse.json({
      error: "Database error",
      details: dbError instanceof Error ? dbError.message : "Unknown",
      checks,
    }, { status: 500 });
  }

  if (!userExists) {
    return NextResponse.json({
      error: "No user found with this email",
      email: email.toLowerCase(),
      checks,
      hint: "Make sure you have an account with this email address",
    }, { status: 404 });
  }

  // Try to send test email
  if (!process.env.RESEND_API_KEY) {
    return NextResponse.json({
      error: "RESEND_API_KEY not configured",
      checks,
    }, { status: 500 });
  }

  const resend = new Resend(process.env.RESEND_API_KEY);
  
  // Generate test token
  const resetToken = crypto.randomBytes(32).toString("hex");
  const baseUrl = process.env.NEXTAUTH_URL || "https://saiflow.io";
  const resetUrl = `${baseUrl}/reset-password?token=${resetToken}`;

  try {
    const { data, error } = await resend.emails.send({
      from: "Saiflow <noreply@saiflow.io>",
      to: email,
      subject: "🧪 Test - Reset your Saiflow password",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #111; color: #fff;">
          <h1 style="color: #0d9488;">🧪 Test Password Reset Email</h1>
          <p>This is a test email to verify the password reset flow is working.</p>
          <p><strong>Reset URL would be:</strong></p>
          <p style="color: #0d9488; word-break: break-all;">${resetUrl}</p>
          <hr style="border-color: #333; margin: 20px 0;">
          <p style="color: #666; font-size: 12px;">
            Sent at: ${new Date().toISOString()}<br>
            Environment: ${process.env.NODE_ENV || "unknown"}
          </p>
        </div>
      `,
    });

    if (error) {
      return NextResponse.json({
        success: false,
        error: "Resend returned an error",
        details: error,
        checks,
      }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: `Test password reset email sent to ${email}`,
      emailId: data?.id,
      checks,
      userExists,
    });

  } catch (err) {
    return NextResponse.json({
      success: false,
      error: err instanceof Error ? err.message : "Unknown error",
      checks,
    }, { status: 500 });
  }
}

