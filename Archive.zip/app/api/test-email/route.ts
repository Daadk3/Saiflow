import { NextResponse } from "next/server";
import { Resend } from 'resend';

export async function GET(req: Request) {
  // Get email from query params
  const { searchParams } = new URL(req.url);
  const testEmail = searchParams.get('email');
  
  if (!testEmail) {
    return NextResponse.json({ error: "Please provide ?email=your@email.com" }, { status: 400 });
  }

  // Check if API key exists
  if (!process.env.RESEND_API_KEY) {
    return NextResponse.json({ 
      error: "RESEND_API_KEY not configured",
      hint: "Add RESEND_API_KEY to Vercel environment variables"
    }, { status: 500 });
  }

  const resend = new Resend(process.env.RESEND_API_KEY);

  try {
    const { data, error } = await resend.emails.send({
      from: 'Saiflow <noreply@saiflow.io>',
      to: testEmail,
      subject: '🧪 Test Email from Saiflow',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #0d9488;">✅ Email is Working!</h1>
          <p>If you're seeing this, your email configuration is correct.</p>
          <p style="color: #666;">Sent at: ${new Date().toISOString()}</p>
          <hr style="border: 1px solid #eee; margin: 20px 0;">
          <p style="color: #999; font-size: 12px;">This is a test email from Saiflow</p>
        </div>
      `,
    });

    if (error) {
      return NextResponse.json({ 
        success: false, 
        error: error,
        message: "Resend returned an error"
      }, { status: 500 });
    }

    return NextResponse.json({ 
      success: true, 
      message: `Test email sent to ${testEmail}`,
      data: data,
      timestamp: new Date().toISOString()
    });

  } catch (err) {
    return NextResponse.json({ 
      success: false, 
      error: err instanceof Error ? err.message : "Unknown error",
      stack: err instanceof Error ? err.stack : undefined
    }, { status: 500 });
  }
}
