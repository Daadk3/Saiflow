import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// Simple admin endpoint to clear all fileUrls
// In production, add proper authentication/authorization
export async function POST(req: Request) {
  try {
    // Optional: Add admin secret check
    const { secret } = await req.json();
    
    // For now, allow if secret matches (set in env) or if no secret required
    // In production, use proper admin authentication
    if (process.env.ADMIN_SECRET && secret !== process.env.ADMIN_SECRET) {
      return NextResponse.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    // Clear all fileUrls
    const result = await prisma.product.updateMany({
      where: {},
      data: {
        fileUrl: null,
      },
    });

    return NextResponse.json({
      success: true,
      message: `Cleared fileUrl for ${result.count} products`,
      count: result.count,
    });
  } catch (error) {
    console.error("Error clearing fileUrls:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}

// GET endpoint to check how many products have fileUrls
export async function GET() {
  try {
    const totalProducts = await prisma.product.count();
    const productsWithFiles = await prisma.product.count({
      where: {
        fileUrl: {
          not: null,
        },
      },
    });
    const productsWithoutFiles = totalProducts - productsWithFiles;

    return NextResponse.json({
      total: totalProducts,
      withFiles: productsWithFiles,
      withoutFiles: productsWithoutFiles,
    });
  } catch (error) {
    console.error("Error getting stats:", error);
    return NextResponse.json(
      { error: "Something went wrong" },
      { status: 500 }
    );
  }
}

