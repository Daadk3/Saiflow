import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

/**
 * Quick admin endpoint to reset fileUrls for all products
 * 
 * Usage:
 * POST /api/admin/reset-products
 * 
 * This will set fileUrl to null for all products, allowing sellers
 * to re-upload their files.
 */
export async function POST(req: Request) {
  try {
    // Clear all fileUrls
    const result = await prisma.product.updateMany({
      where: {},
      data: {
        fileUrl: null,
      },
    });

    return NextResponse.json({
      success: true,
      message: `Reset fileUrl for ${result.count} products. Sellers can now re-upload their files.`,
      count: result.count,
    });
  } catch (error) {
    console.error("Error resetting fileUrls:", error);
    return NextResponse.json(
      { error: "Something went wrong", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 }
    );
  }
}

