import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search");

  try {
    // Get all users (just email for privacy)
    const users = await prisma.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
        createdAt: true,
      },
      take: 20,
      orderBy: { createdAt: "desc" },
    });

    // If search provided, also do a case-insensitive search
    let matchingUser = null;
    if (search) {
      matchingUser = await prisma.user.findFirst({
        where: {
          email: {
            contains: search,
            mode: "insensitive",
          },
        },
        select: {
          id: true,
          email: true,
          name: true,
          createdAt: true,
        },
      });
    }

    return NextResponse.json({
      totalUsers: users.length,
      users: users.map(u => ({
        id: u.id.substring(0, 8) + "...",
        email: u.email,
        name: u.name,
        createdAt: u.createdAt,
      })),
      searchResult: matchingUser ? {
        found: true,
        email: matchingUser.email,
        exactMatch: matchingUser.email.toLowerCase() === search?.toLowerCase(),
      } : {
        found: false,
        searchedFor: search,
      },
    });
  } catch (error) {
    return NextResponse.json({
      error: error instanceof Error ? error.message : "Unknown error",
    }, { status: 500 });
  }
}

